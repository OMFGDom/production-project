import React from 'react';

const jestEmptyComponent = () => <div />;

export default jestEmptyComponent;
